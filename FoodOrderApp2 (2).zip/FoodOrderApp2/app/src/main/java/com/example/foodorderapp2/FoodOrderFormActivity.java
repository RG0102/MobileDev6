package com.example.foodorderapp2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class FoodOrderFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_order);
    }
}
