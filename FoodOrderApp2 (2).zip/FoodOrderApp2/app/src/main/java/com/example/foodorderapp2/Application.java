//package com.example.foodorderapp2;
//
//import android.app.Application;
//import android.database.sqlite.SQLiteCursor;
//
//import androidx.room.Database;
//
//public class Application extends Application{
//
//    @Override
//    public void onCreate( ) {
//        super.onCreate();
//
//        SQLiteCursor DatabaseHelper = null;
//        DatabaseHelper.getDatabase(this);
//    }
//}
